﻿if (!Modernizr.inputtypesypes.Date) {
    $(function () {

        $(".datepicker").datepicker();

    });
}